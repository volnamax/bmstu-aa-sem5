rm *.aux *.log *.out *.bbl *.bcf *.blg *.xml *.toc
